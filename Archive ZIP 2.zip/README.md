
# Yippee Backend (Flask)

Ce projet est une API Flask pour le chatbot vocal éducatif Yippee.

## ✨ Fonctionnalités

- Connexion à OpenAI GPT-3.5
- Synthèse vocale via ElevenLabs
- Mémoire conversationnelle par utilisateur
- Route POST `/ask` compatible avec Framer

## 🛠️ Déploiement sur Render

1. Crée un compte sur [https://render.com](https://render.com)
2. Crée un **nouveau Web Service**
3. Connecte ce repo (ou upload ce dossier)
4. Ajoute 2 variables d’environnement :
   - `OPENAI_API_KEY`
   - `ELEVEN_API_KEY`

## 🎯 Exemple d'appel

POST `/ask`
```json
{
  "name": "Liana",
  "message": "Pourquoi le ciel est bleu ?"
}
```

Réponse :
```json
{
  "text": "Parce que la lumière bleue se diffuse plus dans l'atmosphère.",
  "audio_url": "https://.../static/Liana.mp3"
}
```
